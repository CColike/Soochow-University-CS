#! /usr/bin/env python
# coding=utf-8
from __future__ import division
v_table = {}  # variable table

def update_v_table(name, value):
    v_table[name] = value

def trans(node):
    for c in node.getchildren():
        trans(c)

    # Translation
    # Assignment
    if node.getdata() == '[ASSIGNMENT]':
        ''' statement : VARIABLE '=' NUMBER'''
        value = node.getchild(2).getvalue()
        node.getchild(0).setvalue(value)
        # update v_table
        update_v_table(node.getchild(0).getdata(), value)

    # Operation
    elif node.getdata() == '[OPERATION]':
        '''operation : VARIABLE '=' expr '''
        value = node.getchild(2).getvalue()
        node.getchild(0).setvalue(value)
        # update v_table
        update_v_table(node.getchild(0).getdata(), value)

    elif node.getdata() == '[expr]':
        '''expr : expr '+' term
            | expr '-' term
            | term
        '''
        if (len(node.getchildren()) == 1):
            node.setvalue(node.getchild(0).getvalue())
        else:
            arg0 = node.getchild(0).getvalue()
            arg1 = node.getchild(2).getvalue()
            op = node.getchild(1).getdata()
            if op == '+':
                value = arg0 + arg1
            else:
                value = arg0 - arg1
            # update v_table
            node.setvalue(value)

    elif node.getdata() == '[term]':
        '''term : term '*' factor 
                | term '/' factor
                | factor '''
        if (len(node.getchildren()) == 1):
            node.setvalue(node.getchild(0).getvalue())
        else:
            arg0 = node.getchild(0).getvalue()
            arg1 = node.getchild(2).getvalue()
            op = node.getchild(1).getdata()
            if op == '*':
                value = arg0 * arg1
            else:
                value = arg0 / arg1
            node.setvalue(value)

    elif node.getdata() == '[factor]':
        """factor : id 
                  | '(' expr ')'  """
        if (len(node.getchildren()) == 1):
            if isinstance(node.getchild(0).getdata(), int):
                value = float(node.getchild(0).getdata())
            else:
                value = v_table[node.getchild(0).getdata()]
            node.getchild(0).setvalue(value)
            node.setvalue(value)
        else:
            node.setvalue(node.getchild(1).getvalue())

    # Print
    elif node.getdata() == '[values]':
        '''values : values ',' VARIABLE
                  | VARIABLE'''
        if len(node.getchildren()) == 1:
            arg0 = v_table[node.getchild(0).getdata()]
            print()
        else:
            arg0 = v_table[node.getchild(2).getdata()]
        print(arg0, end=" ")
