#! /usr/bin/env python
# coding=utf-8
from py_yacc import yacc
from util import clear_text
from translation import trans, v_table

tree = ""


def tree_to_str(node):
    global tree
    if node:
        temp = str(node._data)
        temp = temp.replace("'", "").replace("[", "").replace("]", "")
        tree += temp
    if node._children:
        for i in node._children:
            tree += "["
            tree_to_str(i)
            tree += "]"


text = clear_text(open('example.py', 'r').read())

# syntax parse
root = yacc.parse(text)
root.print_node(0)
tree_to_str(root)
print("[" + tree + "]")
# translation
trans(root)
print(v_table)
